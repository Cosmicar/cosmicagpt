module.exports=[33304,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_generator_page_actions_05fp.5u.js.map