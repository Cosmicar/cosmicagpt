module.exports=[18971,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_workspace-settings_page_actions_0c0uor6.js.map