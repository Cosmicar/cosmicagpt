module.exports=[97374,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_automation-center_page_actions_0ceq60-.js.map