module.exports=[79538,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_social-connections_page_actions_0li3cf0.js.map