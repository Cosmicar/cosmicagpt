var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/meta/publish-test/route.js")
R.c("server/chunks/[externals]_next_dist_0arv.vj._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_11xbdvc.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_meta_publish-test_route_actions_06wgbk4.js")
R.m(13899)
module.exports=R.m(13899).exports
