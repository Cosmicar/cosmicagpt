globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/7bbsu2GTGNbh-OiZz6WzH/_buildManifest.js",
    "static/7bbsu2GTGNbh-OiZz6WzH/_ssgManifest.js",
    "static/7bbsu2GTGNbh-OiZz6WzH/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0b5i-yv-ub-pf.js",
    "static/chunks/0pqt~8bl3ukh4.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/0a0or~m.o6s29.js",
    "static/chunks/turbopack-0-cwz-d3l9nv4.js"
  ]
};
