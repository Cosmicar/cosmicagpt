// Cosmica SaaS — desktop shell: sidebar + navbar + main slot.

const NAV_ITEMS = [
  { key: 'dashboard',     label: 'Dashboard',     icon: '📊' },
  { key: 'consola',       label: 'Consola',       icon: '🛰️',  badge: 'LIVE' },
  { key: 'tickets',       label: 'Trabajos',      icon: '🛠️',  count: 12 },
  { key: 'clientes',      label: 'Clientes',      icon: '👥' },
  { key: 'inventario',    label: 'Inventario',    icon: '📦',  alert: 3 },
  { key: 'ventas',        label: 'Ventas',        icon: '💳' },
  { key: 'config',        label: 'Configuración', icon: '⚙️' },
];

function SaaSSidebar({ active = 'dashboard', user = { name: 'Lucas M.', email: 'lucas@cosmica.ar', role: 'admin' } }) {
  return (
    <aside style={{
      width: 250, flexShrink: 0,
      background: COSMICA_SAAS.bgPanel,
      backdropFilter: 'blur(20px)',
      borderRight: `1px solid ${COSMICA_SAAS.border}`,
      display: 'flex', flexDirection: 'column',
      padding: '20px 0',
    }}>
      {/* Logo lock-up */}
      <div style={{ padding: '0 20px 18px',
                    borderBottom: `1px solid ${COSMICA_SAAS.border}`,
                    marginBottom: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: `linear-gradient(135deg, ${COSMICA_SAAS.accentCyan}, ${COSMICA_SAAS.accentOrange})`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 16,
            boxShadow: `0 0 14px ${COSMICA_SAAS.cyanGlow}`,
          }}>🚀</div>
          <div>
            <div style={{ fontFamily: COSMICA_SAAS.fontDisplay,
                          fontWeight: 700, fontSize: 18, color: COSMICA_SAAS.textPrimary,
                          letterSpacing: '0.02em', lineHeight: 1 }}>
              CÓSMICA
            </div>
            <div style={{ fontSize: 9.5, color: COSMICA_SAAS.accentCyan,
                          letterSpacing: '0.18em', fontWeight: 700, marginTop: 2 }}>
              SAAS · v1.0
            </div>
          </div>
        </div>
      </div>

      {/* Nav items */}
      <nav style={{ display: 'flex', flexDirection: 'column',
                    padding: '0 12px', gap: 2, flex: 1 }}>
        {NAV_ITEMS.map((it) => {
          const on = it.key === active;
          return (
            <a key={it.key} href={`#${it.key}`} style={{
              display: 'flex', alignItems: 'center', gap: 12,
              padding: '9px 12px', borderRadius: 8, textDecoration: 'none',
              fontSize: 13.5, fontWeight: on ? 600 : 500,
              color: on ? COSMICA_SAAS.accentCyan : COSMICA_SAAS.textPrimary,
              background: on ? 'rgba(0,229,255,0.10)' : 'transparent',
              borderLeft: on ? `2px solid ${COSMICA_SAAS.accentCyan}` : '2px solid transparent',
              paddingLeft: on ? 14 : 14,
              transition: 'all 0.12s',
            }}>
              <span style={{ fontSize: 15, width: 18 }}>{it.icon}</span>
              <span style={{ flex: 1 }}>{it.label}</span>
              {it.count != null && (
                <span style={{
                  fontFamily: COSMICA_SAAS.fontMono, fontSize: 10.5,
                  background: 'rgba(255,255,255,0.06)',
                  padding: '2px 6px', borderRadius: 4,
                  color: COSMICA_SAAS.textMuted,
                }}>{it.count}</span>
              )}
              {it.alert != null && (
                <span style={{
                  fontSize: 10, fontWeight: 700,
                  background: `${COSMICA_SAAS.accentOrange}22`,
                  color: COSMICA_SAAS.accentOrange,
                  padding: '2px 6px', borderRadius: 4,
                }}>{it.alert} ⚠</span>
              )}
              {it.badge && (
                <span style={{
                  display: 'inline-flex', alignItems: 'center', gap: 4,
                  fontSize: 9, fontWeight: 700, letterSpacing: '0.1em',
                  background: COSMICA_SAAS.success, color: '#050B14',
                  padding: '2px 6px', borderRadius: 4,
                }}>
                  <span style={{
                    width: 5, height: 5, borderRadius: '50%', background: '#050B14',
                    animation: 'cosmica-blink 1.2s ease infinite',
                  }} />
                  {it.badge}
                </span>
              )}
            </a>
          );
        })}
      </nav>

      {/* User card */}
      <div style={{ padding: '12px',
                    borderTop: `1px solid ${COSMICA_SAAS.border}`,
                    marginTop: 12 }}>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 10,
          padding: 10, borderRadius: 8,
          background: 'rgba(255,255,255,0.03)',
          border: `1px solid ${COSMICA_SAAS.border}`,
        }}>
          <SaaSAvatar name={user.name} size={32} />
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontSize: 12.5, fontWeight: 600, color: COSMICA_SAAS.textPrimary,
              whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis',
            }}>{user.name}</div>
            <div style={{ fontSize: 10.5, color: COSMICA_SAAS.textMuted,
                          display: 'flex', alignItems: 'center', gap: 4 }}>
              <span style={{
                width: 5, height: 5, borderRadius: '50%',
                background: COSMICA_SAAS.success,
                boxShadow: `0 0 6px ${COSMICA_SAAS.success}`,
              }} /> {user.role}
            </div>
          </div>
          <span style={{ color: COSMICA_SAAS.textMuted, fontSize: 14 }}>⋯</span>
        </div>
      </div>
    </aside>
  );
}

function SaaSTopbar({ title, breadcrumb, lastSync = 'hace 12 s', actions }) {
  return (
    <header style={{
      height: 65, flexShrink: 0,
      background: 'rgba(5,11,20,0.6)',
      backdropFilter: 'blur(14px)',
      borderBottom: `1px solid ${COSMICA_SAAS.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 28px',
    }}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {breadcrumb && <SaaSBreadcrumb items={breadcrumb} />}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <h1 style={{
            margin: 0, fontFamily: COSMICA_SAAS.fontDisplay,
            fontSize: 22, fontWeight: 700,
            letterSpacing: '-0.01em', color: COSMICA_SAAS.textPrimary,
          }}>{title}</h1>
          <span style={{
            fontSize: 11, color: COSMICA_SAAS.textMuted,
            display: 'inline-flex', alignItems: 'center', gap: 5,
            fontFamily: COSMICA_SAAS.fontMono,
          }}>
            <span style={{
              width: 6, height: 6, borderRadius: '50%',
              background: COSMICA_SAAS.success,
              boxShadow: `0 0 6px ${COSMICA_SAAS.success}`,
            }} /> sync {lastSync}
          </span>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <SaaSInput placeholder="Buscar (Ctrl+K)" icon="🔍" kbd="⌘K"
                   style={{ width: 280 }} />
        {actions}
        <span style={{ fontSize: 12, color: COSMICA_SAAS.textMuted,
                       paddingLeft: 12, borderLeft: `1px solid ${COSMICA_SAAS.border}` }}>
          lucas@cosmica.ar
        </span>
      </div>
    </header>
  );
}

// ─── Desktop "browser" frame for the canvas ─────────────────────────────
function SaaSFrame({ children, w = 1320, h = 820 }) {
  return (
    <div style={{
      width: w, height: h, borderRadius: 14, overflow: 'hidden',
      background: COSMICA_SAAS.bgDark, color: COSMICA_SAAS.textPrimary,
      fontFamily: COSMICA_SAAS.font,
      boxShadow: '0 30px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(255,255,255,0.04)',
      position: 'relative',
    }}>
      {/* macOS-style title bar */}
      <div style={{
        height: 36, background: 'rgba(0,0,0,0.4)',
        borderBottom: `1px solid ${COSMICA_SAAS.border}`,
        display: 'flex', alignItems: 'center', padding: '0 14px', gap: 8,
        flexShrink: 0,
      }}>
        <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#ff5f57' }} />
        <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#ffbd2e' }} />
        <span style={{ width: 12, height: 12, borderRadius: '50%', background: '#28c840' }} />
        <div style={{ flex: 1, display: 'flex', justifyContent: 'center' }}>
          <div style={{
            padding: '4px 14px', borderRadius: 6,
            background: 'rgba(255,255,255,0.05)',
            border: `1px solid ${COSMICA_SAAS.border}`,
            fontSize: 11, color: COSMICA_SAAS.textMuted,
            fontFamily: COSMICA_SAAS.fontMono,
            display: 'flex', alignItems: 'center', gap: 6,
          }}>
            <span style={{ color: COSMICA_SAAS.success }}>🔒</span>
            app.cosmica.ar
          </div>
        </div>
        <div style={{ width: 72 }} />
      </div>
      <div style={{ position: 'relative', height: h - 36, display: 'flex',
                    overflow: 'hidden' }}>
        <SaaSSpaceBg />
        <div style={{ position: 'relative', display: 'flex', width: '100%' }}>
          {children}
        </div>
      </div>
    </div>
  );
}

window.SaaSSidebar = SaaSSidebar;
window.SaaSTopbar = SaaSTopbar;
window.SaaSFrame = SaaSFrame;
