// Cosmica SaaS — Dashboard view.
// Matches apps/cosmica-app/views/dashboard.js layout.

// ─── Mock data ─────────────────────────────────────────────────────────
const MOCK_TICKETS = [
  { id: 't1', num: 'TAL-2941', name: 'Camila Pérez',  equipo: 'Lenovo IdeaPad 3', fecha: '14/05',
    estado: 'En reparación', plan: 'Oro', problema: 'Lentitud extrema y publicidad emergente en Chrome',
    overdue: false, alto: false },
  { id: 't2', num: 'REM-2942', name: 'Diego Ramírez', equipo: 'HP Pavilion 15',   fecha: '14/05',
    estado: 'Ingresado',     plan: 'Bronce', problema: 'No abre Microsoft Office, error 0x80070005',
    overdue: false, alto: false },
  { id: 't3', num: 'TAL-2938', name: 'Sofía Torres',  equipo: 'iMac 27"',         fecha: '12/05',
    estado: 'Listo',         plan: 'Platinum', problema: 'Pasaje a SSD 1TB + clonado de Windows 11',
    overdue: false, alto: true },
  { id: 't4', num: 'REM-2935', name: 'Pablo Gómez',   equipo: 'Asus VivoBook',    fecha: '07/05',
    estado: 'En reparación', plan: 'Oro', problema: 'Pantallazo azul al iniciar — Memory_Management',
    overdue: true,  alto: false },
];

const MOCK_CLIENTS = [
  { id: 'c1', code: 'CLI-0142', name: 'Camila Pérez',  dni: '38.421.119', prov: 'Mendoza',  tel: '+54 261 555 0142' },
  { id: 'c2', code: 'CLI-0141', name: 'Diego Ramírez', dni: '32.118.005', prov: 'Córdoba',  tel: '+54 351 555 0098' },
  { id: 'c3', code: 'CLI-0140', name: 'Tatiana Vidal', dni: '40.502.913', prov: 'Tucumán',  tel: '+54 381 555 0211' },
];

const ESTADO_TONE = {
  'Ingresado':      'cyan',
  'En reparación':  'orange',
  'Listo':          'green',
  'Entregado':      'gray',
  'Reingresada':    'pink',
};

// ─── Ticket Card (matches ticket-card.js layout) ───────────────────────
function SaaSTicketCard({ t, compact = false }) {
  return (
    <SaaSGlassCard padding={compact ? 14 : 18}
      style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ minWidth: 0 }}>
          <div style={{ fontSize: 15, fontWeight: 600, color: COSMICA_SAAS.textPrimary,
                        whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {t.name}
          </div>
          <SaaSOrderNum>#{t.num}</SaaSOrderNum>
          <span style={{ fontSize: 11, color: COSMICA_SAAS.textMuted, marginLeft: 6 }}>
            · {t.fecha}
          </span>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 4 }}>
          <SaaSBadge tone={ESTADO_TONE[t.estado] || 'gray'}>{t.estado}</SaaSBadge>
          {t.overdue && <SaaSBadge tone="pink"  rule>⚠ DEMORADO</SaaSBadge>}
          {t.alto    && <SaaSBadge tone="gold"  rule>💎 ALTO VALOR</SaaSBadge>}
        </div>
      </div>
      {!compact && (
        <>
          <div style={{ fontSize: 12.5, color: COSMICA_SAAS.textMuted, lineHeight: 1.5 }}>
            <div><b style={{ color: COSMICA_SAAS.textPrimary, fontWeight: 500 }}>Equipo:</b> {t.equipo}</div>
            <div><b style={{ color: COSMICA_SAAS.textPrimary, fontWeight: 500 }}>Plan:</b> <span style={{ textTransform: 'capitalize' }}>{t.plan}</span></div>
          </div>
          <div style={{
            borderTop: `1px solid ${COSMICA_SAAS.border}`, paddingTop: 8,
            fontSize: 12.5, color: COSMICA_SAAS.textMuted, lineHeight: 1.45,
          }}>
            <b style={{ color: COSMICA_SAAS.textPrimary, fontWeight: 500 }}>Problema:</b>{' '}
            <span style={{
              display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical',
              overflow: 'hidden',
            }}>{t.problema}</span>
          </div>
        </>
      )}
    </SaaSGlassCard>
  );
}

// ─── Client Card ───────────────────────────────────────────────────────
function SaaSClientCard({ c }) {
  return (
    <SaaSGlassCard padding={18} style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <SaaSAvatar name={c.name} size={40} />
          <div>
            <div style={{ fontSize: 14, fontWeight: 600, color: COSMICA_SAAS.textPrimary }}>
              {c.name}
            </div>
            <div style={{ fontFamily: COSMICA_SAAS.fontMono, fontSize: 11,
                          color: COSMICA_SAAS.accentCyan, marginTop: 2 }}>
              {c.code}
            </div>
          </div>
        </div>
        <SaaSBadge tone="gray">Cliente</SaaSBadge>
      </div>
      <div style={{ fontSize: 12.5, color: COSMICA_SAAS.textMuted, lineHeight: 1.55 }}>
        <div><b style={{ color: COSMICA_SAAS.textPrimary, fontWeight: 500 }}>DNI:</b> {c.dni}</div>
        <div><b style={{ color: COSMICA_SAAS.textPrimary, fontWeight: 500 }}>Tel:</b> {c.tel}</div>
        <div><b style={{ color: COSMICA_SAAS.textPrimary, fontWeight: 500 }}>Provincia:</b> {c.prov}</div>
      </div>
    </SaaSGlassCard>
  );
}

// ─── Main: Dashboard view ──────────────────────────────────────────────
function SaaSDashboardView() {
  return (
    <main style={{ flex: 1, overflow: 'auto', padding: '24px 28px 32px',
                   display: 'flex', flexDirection: 'column', gap: 22 }}>
      {/* Header — exact match to renderContent header */}
      <header style={{ display: 'flex', justifyContent: 'space-between',
                       alignItems: 'flex-end', gap: 16 }}>
        <div>
          <SaaSBadge tone="cyan" style={{ marginBottom: 8 }}>Vista General</SaaSBadge>
          <h1 style={{
            margin: 0, fontFamily: COSMICA_SAAS.fontDisplay,
            fontSize: 32, fontWeight: 800, letterSpacing: '-0.02em',
            color: COSMICA_SAAS.textPrimary,
          }}>Panel Operacional</h1>
          <p style={{ margin: '4px 0 0', color: COSMICA_SAAS.textMuted, fontSize: 13 }}>
            Estado del taller al jueves 14 de mayo, 14:32 · Cobertura nacional 🇦🇷
          </p>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <SaaSButton variant="secondary" size="sm" icon="🔄">Actualizar</SaaSButton>
          <SaaSButton variant="primary"   size="sm" icon="➕">Nuevo Trabajo</SaaSButton>
        </div>
      </header>

      {/* KPI strip */}
      <section style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 14 }}>
        <SaaSKPI label="PENDIENTES"        value="4"  color={COSMICA_SAAS.accentCyan}    icon="⏳" sub="2 nuevas hoy" />
        <SaaSKPI label="EN REPARACIÓN"     value="7"  color={COSMICA_SAAS.accentOrange}  icon="🔧" sub="3 en remoto" />
        <SaaSKPI label="LISTOS"            value="3"  color={COSMICA_SAAS.success}       icon="✅" sub="esperando retiro" />
        <SaaSKPI label="ENTREGADOS HOY"    value="6"  color={COSMICA_SAAS.textMuted}     icon="📦" sub="$89.700 caja" />
        <SaaSKPI label="DEMORADOS"         value="2"  color={COSMICA_SAAS.danger}        icon="⚠️" sub="+7 días sin mover" />
      </section>

      {/* Contable strip */}
      <SaaSGlassCard padding={20}>
        <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr 1fr 1fr', gap: 24,
                      alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
                          color: COSMICA_SAAS.textMuted, textTransform: 'uppercase' }}>
              Contabilidad operativa
            </div>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginTop: 6 }}>
              <span style={{ fontSize: 11, color: COSMICA_SAAS.textMuted }}>Caja del día</span>
              <span style={{ fontFamily: COSMICA_SAAS.fontDisplay, fontSize: 28, fontWeight: 700,
                             color: COSMICA_SAAS.accentCyan, letterSpacing: '-0.01em' }}>
                $89.700
              </span>
            </div>
            <div style={{ fontSize: 11, color: COSMICA_SAAS.textMuted, marginTop: 2 }}>
              Reset a las 00:00 hora local · Argentina
            </div>
          </div>
          {[
            { l: 'Mes en curso',      v: '$1.412.500', sub: '+22% vs abr',     col: COSMICA_SAAS.success },
            { l: 'Comisiones taller', v: '$11.940',    sub: '20% sobre $59,7K', col: COSMICA_SAAS.textPrimary },
            { l: 'Remoto (100%)',     v: '$30.000',    sub: '3 sesiones',      col: COSMICA_SAAS.accentOrange },
          ].map((s, i) => (
            <div key={i} style={{ borderLeft: `1px solid ${COSMICA_SAAS.border}`, paddingLeft: 20 }}>
              <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.06em',
                            color: COSMICA_SAAS.textMuted, textTransform: 'uppercase' }}>
                {s.l}
              </div>
              <div style={{ fontFamily: COSMICA_SAAS.fontDisplay, fontSize: 22, fontWeight: 700,
                            color: s.col, marginTop: 4, letterSpacing: '-0.01em' }}>
                {s.v}
              </div>
              <div style={{ fontSize: 11, color: COSMICA_SAAS.textMuted, marginTop: 2 }}>
                {s.sub}
              </div>
            </div>
          ))}
        </div>
      </SaaSGlassCard>

      {/* Two columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 22 }}>
        <section>
          <SaaSSectionDivider title="Últimos Movimientos" icon="🛠️" action="Ver Todos" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {MOCK_TICKETS.slice(0, 3).map((t) => <SaaSTicketCard key={t.id} t={t} />)}
          </div>
        </section>
        <section>
          <SaaSSectionDivider title="Nuevos Clientes" icon="👥" action="Ver Todos" />
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {MOCK_CLIENTS.map((c) => <SaaSClientCard key={c.id} c={c} />)}
          </div>
        </section>
      </div>
    </main>
  );
}

window.MOCK_TICKETS = MOCK_TICKETS;
window.MOCK_CLIENTS = MOCK_CLIENTS;
window.ESTADO_TONE = ESTADO_TONE;
window.SaaSTicketCard = SaaSTicketCard;
window.SaaSClientCard = SaaSClientCard;
window.SaaSDashboardView = SaaSDashboardView;
