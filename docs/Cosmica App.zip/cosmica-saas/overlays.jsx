// Cosmica SaaS — overlays: command palette + ticket quick-view drawer.

// ─── Command Palette ──────────────────────────────────────────────────
function SaaSCommandPalette() {
  return (
    <div style={{
      position: 'absolute', inset: 0,
      background: 'rgba(5,11,20,0.82)',
      backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
      paddingTop: 70, zIndex: 90,
    }}>
      <div style={{
        width: 720, maxWidth: 'calc(100% - 80px)',
        background: '#0a1120',
        border: `1px solid rgba(255,255,255,0.12)`,
        borderRadius: 16, overflow: 'hidden',
        display: 'flex', flexDirection: 'column',
        boxShadow: '0 24px 60px rgba(0,0,0,0.7), 0 0 0 1px rgba(0,229,255,0.04)',
      }}>
        {/* Search row */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10,
                      padding: '14px 22px',
                      borderBottom: `1px solid ${COSMICA_SAAS.border}` }}>
          <span style={{ fontSize: 18, opacity: 0.5 }}>🔍</span>
          <span style={{ flex: 1, fontSize: 15, color: COSMICA_SAAS.textPrimary,
                         caretColor: COSMICA_SAAS.accentCyan }}>
            <span>cam</span>
            <span style={{
              display: 'inline-block', width: 2, height: 16,
              background: COSMICA_SAAS.accentCyan, verticalAlign: 'middle',
              marginLeft: 2, animation: 'cosmica-blink 1s ease infinite',
            }} />
          </span>
          <span style={{
            fontSize: 11, padding: '2px 7px', borderRadius: 4,
            background: 'rgba(255,255,255,0.06)',
            border: `1px solid ${COSMICA_SAAS.border}`,
            color: COSMICA_SAAS.textMuted, fontFamily: COSMICA_SAAS.fontMono,
          }}>ESC</span>
        </div>

        <div style={{ maxHeight: 460, overflow: 'auto', padding: '6px 0' }}>
          {/* Group: Tickets */}
          <div style={{ padding: '6px 0' }}>
            <div style={{
              fontSize: 10, fontWeight: 700, letterSpacing: '0.07em',
              color: COSMICA_SAAS.textMuted, textTransform: 'uppercase',
              padding: '8px 22px',
            }}>Trabajos · 2 resultados</div>
            {[
              { ic: '🛠️', l: '#TAL-2941 · Camila Pérez', s: 'En reparación · Lenovo IdeaPad 3', active: true },
              { ic: '🛠️', l: '#REM-2912 · Camila Pérez', s: 'Entregado · hace 23 días' },
            ].map((it, i) => (
              <CPItem key={i} {...it} />
            ))}
          </div>

          {/* Group: Clientes */}
          <div style={{ padding: '6px 0' }}>
            <div style={{
              fontSize: 10, fontWeight: 700, letterSpacing: '0.07em',
              color: COSMICA_SAAS.textMuted, textTransform: 'uppercase',
              padding: '8px 22px',
            }}>Clientes · 1 resultado</div>
            <CPItem ic="👤" l="Camila Pérez" s="CLI-0142 · Mendoza · DNI 38.421.119" />
          </div>

          {/* Group: Acciones rápidas */}
          <div style={{ padding: '6px 0' }}>
            <div style={{
              fontSize: 10, fontWeight: 700, letterSpacing: '0.07em',
              color: COSMICA_SAAS.textMuted, textTransform: 'uppercase',
              padding: '8px 22px',
            }}>Acciones</div>
            <CPItem ic="➕" l="Nuevo trabajo para Camila Pérez" s="Pre-completa los datos del cliente" />
            <CPItem ic="🛰️" l="Abrir consola remota"               s="Conectarse a CAMILA-PC" />
            <CPItem ic="🖨️" l="Imprimir orden #TAL-2941"           s="Generar comprobante para entregar" />
          </div>
        </div>

        {/* Footer */}
        <div style={{
          display: 'flex', gap: 18, padding: '8px 22px',
          borderTop: `1px solid ${COSMICA_SAAS.border}`,
          fontSize: 11, color: COSMICA_SAAS.textMuted, opacity: 0.7,
        }}>
          <span><kbd style={kbdStyle}>↑↓</kbd> navegar</span>
          <span><kbd style={kbdStyle}>↩</kbd> abrir</span>
          <span><kbd style={kbdStyle}>⌘</kbd> + <kbd style={kbdStyle}>K</kbd> alternar</span>
          <span style={{ flex: 1 }} />
          <span>powered by Cósmica</span>
        </div>
      </div>
    </div>
  );
}

const kbdStyle = {
  fontSize: 10, padding: '1px 5px', borderRadius: 3,
  background: 'rgba(255,255,255,0.08)',
  border: '1px solid rgba(255,255,255,0.1)',
  color: '#8A99AD', fontFamily: '"JetBrains Mono", monospace',
};

function CPItem({ ic, l, s, active }) {
  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 14,
      padding: '9px 22px',
      borderLeft: `2px solid ${active ? COSMICA_SAAS.accentCyan : 'transparent'}`,
      background: active ? 'rgba(0,229,255,0.07)' : 'transparent',
      cursor: 'pointer',
    }}>
      <div style={{
        width: 32, height: 32, borderRadius: 6,
        background: 'rgba(255,255,255,0.04)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 15, flexShrink: 0,
      }}>{ic}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 500, color: COSMICA_SAAS.textPrimary,
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {l}
        </div>
        <div style={{ fontSize: 11.5, color: COSMICA_SAAS.textMuted, marginTop: 1,
                      whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
          {s}
        </div>
      </div>
      {active && (
        <span style={{ fontSize: 11, color: COSMICA_SAAS.accentCyan,
                       fontFamily: COSMICA_SAAS.fontMono }}>↩</span>
      )}
    </div>
  );
}

// ─── Ticket Drawer (right-side panel over a Dashboard backdrop) ───────
function SaaSTicketDrawer() {
  return (
    <>
      {/* dim backdrop */}
      <div style={{ position: 'absolute', inset: 0,
                    background: 'rgba(5,11,20,0.75)',
                    backdropFilter: 'blur(3px)', zIndex: 90 }} />
      {/* drawer panel */}
      <div style={{
        position: 'absolute', top: 0, right: 0, bottom: 0,
        width: 500, background: '#080f1c',
        borderLeft: `1px solid ${COSMICA_SAAS.border}`,
        zIndex: 91, display: 'flex', flexDirection: 'column',
      }}>
        {/* Header */}
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          gap: 14, padding: '16px 22px',
          borderBottom: `1px solid ${COSMICA_SAAS.border}`,
          background: 'rgba(255,255,255,0.02)',
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <SaaSOrderNum>#TAL-2941</SaaSOrderNum>
              <SaaSBadge tone="orange">En reparación</SaaSBadge>
              <SaaSBadge tone="gold" rule>💎 ALTO VALOR</SaaSBadge>
            </div>
            <div style={{ marginTop: 5, fontSize: 15, fontWeight: 600,
                          color: COSMICA_SAAS.textPrimary }}>
              Camila Pérez · Lenovo IdeaPad 3
            </div>
          </div>
          <button style={{
            width: 32, height: 32, borderRadius: 6,
            background: 'transparent', border: `1px solid ${COSMICA_SAAS.border}`,
            color: COSMICA_SAAS.textMuted, fontSize: 14, cursor: 'pointer',
          }}>✕</button>
        </div>

        {/* Body */}
        <div style={{ flex: 1, overflow: 'auto', padding: 22,
                      display: 'flex', flexDirection: 'column', gap: 20 }}>
          {/* Meta grid */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
            {[
              { l: 'Tipo',         v: 'Taller'   },
              { l: 'Plan',         v: 'Oro · $29.900' },
              { l: 'Fecha ingreso', v: '14/05/2026 11:14' },
              { l: 'Días en sistema', v: '0 días' },
              { l: 'Técnico',      v: 'Lucas M.' },
              { l: 'Garantía',     v: '90 días Cósmica' },
            ].map((m, i) => (
              <div key={i}>
                <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.06em',
                              color: COSMICA_SAAS.textMuted, textTransform: 'uppercase' }}>
                  {m.l}
                </div>
                <div style={{ fontSize: 13, color: COSMICA_SAAS.textPrimary,
                              fontWeight: 500, marginTop: 2 }}>{m.v}</div>
              </div>
            ))}
          </div>

          <div style={{ height: 1, background: COSMICA_SAAS.border }} />

          {/* Problem */}
          <div>
            <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.06em',
                          color: COSMICA_SAAS.textMuted, textTransform: 'uppercase',
                          marginBottom: 8 }}>
              Problema reportado
            </div>
            <div style={{ fontSize: 13.5, color: COSMICA_SAAS.textPrimary, lineHeight: 1.5 }}>
              Mi notebook se trabó esta mañana y desde ayer cuando abro Chrome aparece publicidad de la nada. Tengo trabajo para entregar mañana.
            </div>
          </div>

          <div style={{ height: 1, background: COSMICA_SAAS.border }} />

          {/* Timeline */}
          <div>
            <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.06em',
                          color: COSMICA_SAAS.textMuted, textTransform: 'uppercase',
                          marginBottom: 12 }}>
              Historial de la orden
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
              {[
                { t: '14:32', tone: 'orange', text: 'Pasó a En reparación',          by: 'Lucas M.', last: false },
                { t: '14:24', tone: 'cyan',   text: 'Presupuesto aprobado',          by: 'Camila P.', last: false },
                { t: '14:18', tone: 'cyan',   text: 'Diagnóstico cargado',           by: 'Lucas M.', last: false },
                { t: '11:14', tone: 'gray',   text: 'Orden creada · Plan Oro',       by: 'Recepción', last: true  },
              ].map((e, i) => (
                <div key={i} style={{ display: 'flex', gap: 12, position: 'relative' }}>
                  <div style={{ width: 22, position: 'relative', flexShrink: 0 }}>
                    <span style={{
                      position: 'absolute', top: 5, left: 6,
                      width: 10, height: 10, borderRadius: '50%',
                      background: { orange: COSMICA_SAAS.accentOrange,
                                    cyan: COSMICA_SAAS.accentCyan,
                                    gray: COSMICA_SAAS.textMuted }[e.tone],
                      boxShadow: `0 0 10px ${{ orange: COSMICA_SAAS.orangeGlow,
                                              cyan: COSMICA_SAAS.cyanGlow,
                                              gray: 'transparent' }[e.tone]}`,
                    }} />
                    {!e.last && (
                      <span style={{
                        position: 'absolute', top: 16, bottom: -8, left: 10.5,
                        width: 1, background: COSMICA_SAAS.border,
                      }} />
                    )}
                  </div>
                  <div style={{ flex: 1, paddingBottom: 16 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between',
                                  alignItems: 'baseline' }}>
                      <span style={{ fontSize: 13, fontWeight: 500,
                                     color: COSMICA_SAAS.textPrimary }}>{e.text}</span>
                      <span style={{ fontFamily: COSMICA_SAAS.fontMono, fontSize: 11,
                                     color: COSMICA_SAAS.textMuted }}>14/05 · {e.t}</span>
                    </div>
                    <div style={{ fontSize: 11.5, color: COSMICA_SAAS.textMuted, marginTop: 2 }}>
                      por {e.by}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div style={{
          padding: '14px 22px', borderTop: `1px solid ${COSMICA_SAAS.border}`,
          display: 'flex', gap: 8, background: 'rgba(255,255,255,0.02)',
        }}>
          <SaaSButton variant="secondary" size="md" style={{ flex: 1 }} icon="📝">Editar</SaaSButton>
          <SaaSButton variant="secondary" size="md" icon="🖨">Imprimir</SaaSButton>
          <SaaSButton variant="primary"   size="md" style={{ flex: 1 }} icon="✓">Marcar Listo</SaaSButton>
        </div>
      </div>
    </>
  );
}

window.SaaSCommandPalette = SaaSCommandPalette;
window.SaaSTicketDrawer = SaaSTicketDrawer;
