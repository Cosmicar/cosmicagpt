// Cosmica SaaS — Trabajos view with table mode + bulk action bar.

const TABLE_ROWS = [
  { id: '1', sel: true,  num: 'TAL-2941', name: 'Camila Pérez',   estado: 'En reparación', equipo: 'Lenovo IdeaPad 3', fecha: '14/05', plan: 'Oro',      type: 'taller', overdue: false, alto: false },
  { id: '2', sel: true,  num: 'REM-2942', name: 'Diego Ramírez',  estado: 'Ingresado',     equipo: 'HP Pavilion 15',   fecha: '14/05', plan: 'Bronce',   type: 'remoto', overdue: false, alto: false },
  { id: '3', sel: true,  num: 'TAL-2940', name: 'Mariano López',  estado: 'Ingresado',     equipo: 'Dell Inspiron',    fecha: '14/05', plan: 'Estándar', type: 'taller', overdue: false, alto: false },
  { id: '4', sel: false, num: 'TAL-2938', name: 'Sofía Torres',   estado: 'Listo',         equipo: 'iMac 27"',         fecha: '12/05', plan: 'Platinum', type: 'taller', overdue: false, alto: true  },
  { id: '5', sel: false, num: 'REM-2937', name: 'Tatiana Vidal',  estado: 'Entregado',     equipo: 'Asus ZenBook',     fecha: '11/05', plan: 'Oro',      type: 'remoto', overdue: false, alto: false },
  { id: '6', sel: false, num: 'REM-2935', name: 'Pablo Gómez',    estado: 'En reparación', equipo: 'Asus VivoBook',    fecha: '07/05', plan: 'Oro',      type: 'remoto', overdue: true,  alto: false },
  { id: '7', sel: false, num: 'TAL-2932', name: 'Esteban Funes',  estado: 'En reparación', equipo: 'PC Armada Intel',  fecha: '04/05', plan: 'Estándar', type: 'taller', overdue: true,  alto: false },
  { id: '8', sel: false, num: 'TAL-2928', name: 'I. Millaleu',    estado: 'Listo',         equipo: 'MacBook Pro 14',   fecha: '02/05', plan: 'Platinum', type: 'taller', overdue: false, alto: true  },
  { id: '9', sel: false, num: 'REM-2925', name: 'Martín Domínguez', estado: 'Entregado',   equipo: 'HP Notebook',      fecha: '30/04', plan: 'Bronce',   type: 'remoto', overdue: false, alto: false },
];

function TableRow({ r }) {
  return (
    <tr style={{
      borderBottom: '1px solid rgba(255,255,255,0.04)',
      background: r.sel ? 'rgba(0,229,255,0.06)' : 'transparent',
    }}>
      <td style={{ padding: '11px 14px', width: 36 }}>
        <input type="checkbox" defaultChecked={r.sel} readOnly
          style={{ width: 14, height: 14, accentColor: COSMICA_SAAS.accentCyan,
                   opacity: r.sel ? 1 : 0.3 }} />
      </td>
      <td style={{ padding: '11px 14px' }}>
        <SaaSOrderNum>#{r.num}</SaaSOrderNum>
      </td>
      <td style={{ padding: '11px 14px', fontSize: 13, fontWeight: 500,
                   color: COSMICA_SAAS.textPrimary }}>{r.name}</td>
      <td style={{ padding: '11px 14px' }}>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 3, alignItems: 'flex-start' }}>
          <SaaSBadge tone={ESTADO_TONE[r.estado] || 'gray'}>{r.estado}</SaaSBadge>
          {r.overdue && <SaaSBadge tone="pink" rule>⚠ DEMORADO</SaaSBadge>}
          {r.alto    && <SaaSBadge tone="gold" rule>💎 ALTO VALOR</SaaSBadge>}
        </div>
      </td>
      <td style={{ padding: '11px 14px', fontSize: 12.5, color: COSMICA_SAAS.textMuted }}>
        {r.equipo}
      </td>
      <td style={{ padding: '11px 14px', fontSize: 11.5, color: COSMICA_SAAS.textMuted,
                   fontFamily: COSMICA_SAAS.fontMono }}>
        {r.fecha}
      </td>
      <td style={{ padding: '11px 14px' }}>
        <SaaSBadge tone={r.type === 'remoto' ? 'cyan' : 'gray'}>{r.type}</SaaSBadge>
      </td>
      <td style={{ padding: '11px 14px', fontSize: 12, color: COSMICA_SAAS.textMuted,
                   textTransform: 'capitalize' }}>{r.plan}</td>
      <td style={{ padding: '11px 14px' }}>
        <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
          {r.estado === 'Ingresado' ? (
            <SaaSButton size="sm" variant="primary" icon="🔧">Pasar a reparación</SaaSButton>
          ) : (
            <select disabled style={{
              background: 'rgba(255,255,255,0.05)', border: `1px solid ${COSMICA_SAAS.border}`,
              borderRadius: 4, color: COSMICA_SAAS.textPrimary,
              fontSize: 11.5, padding: '4px 8px', minWidth: 110,
              fontFamily: COSMICA_SAAS.font,
            }}>
              <option>{r.estado}</option>
            </select>
          )}
          <SaaSButton size="sm" variant="secondary" style={{ padding: '4px 8px' }}>📝</SaaSButton>
          <SaaSButton size="sm" variant="secondary" style={{ padding: '4px 8px' }}>🖨</SaaSButton>
        </div>
      </td>
    </tr>
  );
}

function SaaSTrabajosView() {
  const sel = TABLE_ROWS.filter((r) => r.sel).length;
  return (
    <main style={{ flex: 1, overflow: 'auto', padding: '24px 28px 90px',
                   display: 'flex', flexDirection: 'column', gap: 18, position: 'relative' }}>
      <div>
        <SaaSBreadcrumb items={[
          { label: 'Operaciones', icon: '⚙️' },
          { label: 'Trabajos',    icon: '🛠️' },
        ]} />
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <h1 style={{
              margin: 0, fontFamily: COSMICA_SAAS.fontDisplay,
              fontSize: 28, fontWeight: 800, letterSpacing: '-0.02em',
              color: COSMICA_SAAS.textPrimary,
            }}>Tickets / Trabajos</h1>
            <p style={{ margin: '4px 0 0', color: COSMICA_SAAS.textMuted, fontSize: 13 }}>
              Listado de órdenes de servicio en el sistema · {TABLE_ROWS.length} resultados
            </p>
          </div>
          <div style={{ display: 'flex', gap: 8 }}>
            <SaaSButton variant="ghost" size="sm" icon="⬇">Exportar CSV</SaaSButton>
            <SaaSButton variant="primary" size="sm" icon="➕">Nuevo Trabajo</SaaSButton>
          </div>
        </div>
      </div>

      {/* Controls row */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
        <SaaSInput placeholder="Buscar por cliente, orden o problema..." icon="🔍"
                   style={{ flex: 1, minWidth: 280, maxWidth: 480 }} />
        <SaaSPillGroup options={['Todos', 'Pendiente', 'En proceso', 'Finalizado']} active="Todos" />
        <SaaSPillGroup options={['Taller', 'Remoto', 'Mixto']} active="Taller" />

        {/* Demora filters (admin only) */}
        <div style={{
          display: 'flex', gap: 4, padding: 4,
          background: 'rgba(255,170,0,0.06)',
          border: `1px solid rgba(255,170,0,0.2)`,
          borderRadius: 8,
        }}>
          {['+3d', '+7d', '+15d'].map((d) => (
            <button key={d} style={{
              padding: '5px 10px', borderRadius: 6, fontSize: 11.5, fontWeight: 600,
              background: 'transparent',
              color: COSMICA_SAAS.accentOrange,
              border: '1px solid transparent', opacity: 0.7, cursor: 'pointer',
            }}>{d}</button>
          ))}
        </div>

        <div style={{ flex: 1 }} />

        {/* View mode selector */}
        <div style={{ display: 'flex', gap: 3, padding: 4,
                      background: 'rgba(255,255,255,0.04)',
                      border: `1px solid ${COSMICA_SAAS.border}`, borderRadius: 8 }}>
          {[
            { k: '⊟', t: 'Compacto'  },
            { k: '⊞', t: 'Normal',     active: false },
            { k: '▦', t: 'Expandido' },
            { k: '≡', t: 'Tabla',      active: true  },
          ].map((m, i) => (
            <button key={i} title={m.t} style={{
              minWidth: 30, height: 28, fontSize: 14,
              background: m.active ? 'rgba(0,229,255,0.15)' : 'transparent',
              border: m.active ? `1px solid ${COSMICA_SAAS.accentCyan}` : '1px solid transparent',
              color: m.active ? COSMICA_SAAS.accentCyan : COSMICA_SAAS.textMuted,
              borderRadius: 5, cursor: 'pointer', opacity: m.active ? 1 : 0.6,
            }}>{m.k}</button>
          ))}
        </div>
      </div>

      {/* Active filter pills */}
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        <SaaSBadge tone="cyan">Solo activos</SaaSBadge>
        <SaaSBadge tone="orange">⚠ Abandonados</SaaSBadge>
        <SaaSBadge tone="green">📦 Listos para entrega</SaaSBadge>
      </div>

      {/* Table */}
      <div style={{
        background: 'linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.01) 100%)',
        backdropFilter: 'blur(10px)',
        border: `1px solid ${COSMICA_SAAS.border}`, borderRadius: 12,
        overflow: 'hidden',
      }}>
        <table style={{ width: '100%', borderCollapse: 'collapse',
                        fontSize: 13, color: COSMICA_SAAS.textPrimary }}>
          <thead>
            <tr style={{ background: 'rgba(5,11,20,0.6)',
                         borderBottom: `1px solid ${COSMICA_SAAS.border}` }}>
              {['', 'Orden', 'Cliente', 'Estado', 'Equipo', 'Fecha', 'Tipo', 'Plan', 'Acciones'].map((h, i) => (
                <th key={i} style={{
                  padding: '10px 14px', textAlign: 'left',
                  fontSize: 10.5, fontWeight: 700, color: COSMICA_SAAS.textMuted,
                  textTransform: 'uppercase', letterSpacing: '0.08em',
                  whiteSpace: 'nowrap',
                }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {TABLE_ROWS.map((r) => <TableRow key={r.id} r={r} />)}
          </tbody>
        </table>
      </div>

      {/* Bulk action bar — sticky bottom */}
      {sel > 0 && (
        <div style={{
          position: 'absolute', left: 0, right: 0, bottom: 0,
          background: 'rgba(8,15,28,0.97)',
          backdropFilter: 'blur(14px)',
          borderTop: `1px solid ${COSMICA_SAAS.accentCyan}`,
          boxShadow: `0 -4px 24px ${COSMICA_SAAS.cyanGlow}`,
          padding: '14px 28px',
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        }}>
          <span style={{ fontSize: 13.5, fontWeight: 600, color: COSMICA_SAAS.accentCyan }}>
            {sel} tickets seleccionados
          </span>
          <div style={{ display: 'flex', gap: 8 }}>
            <button style={{
              padding: '6px 14px', borderRadius: 8,
              background: 'rgba(0,229,255,0.08)',
              border: `1px solid rgba(0,229,255,0.3)`,
              color: COSMICA_SAAS.accentCyan, fontSize: 13, fontWeight: 600,
              fontFamily: COSMICA_SAAS.font, cursor: 'pointer',
            }}>En Reparación</button>
            <button style={{
              padding: '6px 14px', borderRadius: 8,
              background: 'rgba(0,229,255,0.08)',
              border: `1px solid rgba(0,229,255,0.3)`,
              color: COSMICA_SAAS.accentCyan, fontSize: 13, fontWeight: 600,
              fontFamily: COSMICA_SAAS.font, cursor: 'pointer',
            }}>Marcar Listo</button>
            <button style={{
              padding: '6px 14px', borderRadius: 8,
              background: 'rgba(0,229,255,0.08)',
              border: `1px solid rgba(0,229,255,0.3)`,
              color: COSMICA_SAAS.accentCyan, fontSize: 13, fontWeight: 600,
              fontFamily: COSMICA_SAAS.font, cursor: 'pointer',
            }}>Entregado</button>
            <button style={{
              padding: '6px 14px', borderRadius: 8,
              background: 'transparent',
              border: `1px solid ${COSMICA_SAAS.border}`,
              color: COSMICA_SAAS.textMuted, fontSize: 13, fontWeight: 500,
              fontFamily: COSMICA_SAAS.font, cursor: 'pointer',
            }}>✕ Limpiar</button>
          </div>
        </div>
      )}
    </main>
  );
}

window.SaaSTrabajosView = SaaSTrabajosView;
