// Cosmica SaaS — atoms (badges, cards, KPIs, sidebar items).
// Visual language mirrors the actual repo's design-system.css:
//   bg-dark #050B14, accent-cyan #00e5ff, glass cards, Inter, etc.

const COSMICA_SAAS = {
  bgDark:        '#050B14',
  bgPanel:       'rgba(5, 11, 20, 0.8)',
  bgCard:        'rgba(255, 255, 255, 0.03)',
  textPrimary:   '#FFFFFF',
  textMuted:     '#8A99AD',
  border:        'rgba(255, 255, 255, 0.1)',
  accentCyan:    '#00e5ff',
  cyanGlow:      'rgba(0, 229, 255, 0.3)',
  accentOrange:  '#ffaa00',
  orangeGlow:    'rgba(255, 170, 0, 0.3)',
  danger:        '#ff007f',
  success:       '#10b981',
  gold:          '#ffc107',
  font:          '"Inter", system-ui, -apple-system, sans-serif',
  fontMono:      '"JetBrains Mono", ui-monospace, monospace',
  fontDisplay:   '"Rajdhani", "Inter", sans-serif',
};

// ─── Glass card ────────────────────────────────────────────────────────
function GlassCard({ children, style, hover = false, selected = false, padding = 24 }) {
  return (
    <div style={{
      background: 'linear-gradient(135deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0.01) 100%)',
      backdropFilter: 'blur(10px)',
      border: `1px solid ${selected ? COSMICA_SAAS.accentCyan : COSMICA_SAAS.border}`,
      borderRadius: 12,
      padding,
      boxShadow: selected ? `0 0 14px ${COSMICA_SAAS.cyanGlow}, 0 10px 30px rgba(0,0,0,0.3)` : undefined,
      transition: 'border-color 0.15s, box-shadow 0.15s',
      ...style,
    }}>{children}</div>
  );
}

// ─── Badges (cyan/orange/green/gray/gold/danger) ───────────────────────
function Badge({ tone = 'gray', children, rule = false, style }) {
  const tones = {
    cyan:   { bg: 'rgba(0,229,255,0.15)',  c: COSMICA_SAAS.accentCyan,    bd: 'rgba(0,229,255,0.3)' },
    orange: { bg: 'rgba(255,170,0,0.15)',  c: COSMICA_SAAS.accentOrange,  bd: 'rgba(255,170,0,0.3)' },
    green:  { bg: 'rgba(16,185,129,0.15)', c: COSMICA_SAAS.success,       bd: 'rgba(16,185,129,0.3)' },
    gray:   { bg: 'rgba(138,153,173,0.15)',c: COSMICA_SAAS.textMuted,     bd: 'rgba(138,153,173,0.25)' },
    gold:   { bg: 'rgba(255,193,7,0.15)',  c: COSMICA_SAAS.gold,          bd: 'rgba(255,193,7,0.3)' },
    pink:   { bg: 'rgba(255,0,127,0.15)',  c: COSMICA_SAAS.danger,        bd: 'rgba(255,0,127,0.3)' },
  };
  const t = tones[tone] || tones.gray;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      padding: rule ? '2px 6px' : '3px 9px',
      borderRadius: 999, fontSize: rule ? 9 : 11,
      fontWeight: 700, letterSpacing: rule ? '0.3px' : '0.04em',
      background: t.bg, color: t.c,
      border: `1px solid ${t.bd}`,
      ...style,
    }}>{children}</span>
  );
}

// ─── Button (matches .btn-primary / .btn-secondary) ────────────────────
function Button({ children, variant = 'primary', size = 'md', icon, style, onClick }) {
  const padding = size === 'sm' ? '5px 11px' : size === 'lg' ? '12px 22px' : '8px 16px';
  const fs      = size === 'sm' ? 12 : size === 'lg' ? 15 : 13.5;

  const styles = {
    primary:   {
      bg: COSMICA_SAAS.accentCyan, color: '#050B14',
      bd: COSMICA_SAAS.accentCyan,
      shadow: `0 0 14px ${COSMICA_SAAS.cyanGlow}`,
    },
    secondary: {
      bg: 'rgba(255,255,255,0.05)', color: COSMICA_SAAS.textPrimary,
      bd: COSMICA_SAAS.border, shadow: 'none',
    },
    ghost: {
      bg: 'transparent', color: COSMICA_SAAS.textMuted,
      bd: COSMICA_SAAS.border, shadow: 'none',
    },
    danger: {
      bg: 'rgba(255,0,127,0.08)', color: COSMICA_SAAS.danger,
      bd: 'rgba(255,0,127,0.4)', shadow: 'none',
    },
  };
  const v = styles[variant] || styles.primary;
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding, fontFamily: COSMICA_SAAS.font, fontSize: fs, fontWeight: 600,
      background: v.bg, color: v.color, border: `1px solid ${v.bd}`,
      borderRadius: 8, cursor: 'pointer', boxShadow: v.shadow,
      letterSpacing: '0.01em',
      ...style,
    }}>{icon && <span style={{ lineHeight: 1 }}>{icon}</span>}{children}</button>
  );
}

// ─── KPI card (matches dashboard.renderKPI exactly) ────────────────────
function KPI({ label, value, color, icon, sub }) {
  return (
    <GlassCard padding={20} style={{
      borderLeft: `4px solid ${color}`,
      display: 'flex', flexDirection: 'column', gap: 4,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <span style={{
          fontSize: 10, color: COSMICA_SAAS.textMuted, fontWeight: 700,
          letterSpacing: '0.5px', textTransform: 'uppercase',
        }}>{label}</span>
        <span style={{ fontSize: 16, opacity: 0.8 }}>{icon}</span>
      </div>
      <div style={{
        fontSize: 38, fontWeight: 800, color, lineHeight: 1.05, marginTop: 4,
        fontFamily: COSMICA_SAAS.fontDisplay, letterSpacing: '-0.02em',
      }}>{value}</div>
      {sub && (
        <div style={{ fontSize: 11, color: COSMICA_SAAS.textMuted, marginTop: 2 }}>{sub}</div>
      )}
    </GlassCard>
  );
}

// ─── Input ─────────────────────────────────────────────────────────────
function Input({ placeholder, icon, style, value, kbd }) {
  return (
    <div style={{ position: 'relative', ...style }}>
      {icon && (
        <span style={{
          position: 'absolute', left: 14, top: '50%',
          transform: 'translateY(-50%)', opacity: 0.5,
          pointerEvents: 'none', fontSize: 14,
        }}>{icon}</span>
      )}
      <div style={{
        width: '100%',
        padding: `9px 14px 9px ${icon ? 38 : 14}px`,
        background: 'rgba(255,255,255,0.04)',
        border: `1px solid ${COSMICA_SAAS.border}`,
        borderRadius: 8, color: value ? COSMICA_SAAS.textPrimary : COSMICA_SAAS.textMuted,
        fontSize: 13.5, fontFamily: COSMICA_SAAS.font,
        display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      }}>
        <span>{value || placeholder}</span>
        {kbd && (
          <span style={{
            fontSize: 10, padding: '1px 6px', borderRadius: 3,
            background: 'rgba(255,255,255,0.08)', border: `1px solid ${COSMICA_SAAS.border}`,
            color: COSMICA_SAAS.textMuted, fontFamily: COSMICA_SAAS.fontMono,
          }}>{kbd}</span>
        )}
      </div>
    </div>
  );
}

// ─── Pill filter group ─────────────────────────────────────────────────
function PillGroup({ options, active }) {
  return (
    <div style={{
      display: 'flex', gap: 4, padding: 4,
      background: 'rgba(255,255,255,0.05)',
      border: `1px solid ${COSMICA_SAAS.border}`,
      borderRadius: 8,
    }}>
      {options.map((o) => {
        const on = o === active;
        return (
          <button key={o} style={{
            padding: '5px 12px', borderRadius: 6,
            fontSize: 12, fontWeight: 600, fontFamily: COSMICA_SAAS.font,
            background: on ? 'rgba(0,229,255,0.15)' : 'transparent',
            border: on ? `1px solid ${COSMICA_SAAS.accentCyan}` : '1px solid transparent',
            color: on ? COSMICA_SAAS.accentCyan : COSMICA_SAAS.textMuted,
            opacity: on ? 1 : 0.65, cursor: 'pointer',
          }}>{o}</button>
        );
      })}
    </div>
  );
}

// ─── Section divider header ────────────────────────────────────────────
function SectionDivider({ title, icon, action }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      borderBottom: `1px solid ${COSMICA_SAAS.border}`,
      paddingBottom: 6, marginBottom: 16, marginTop: 8,
    }}>
      <h3 style={{
        margin: 0, fontSize: 15, fontWeight: 700,
        color: COSMICA_SAAS.textPrimary,
        display: 'flex', alignItems: 'center', gap: 8,
      }}>
        {icon && <span style={{ opacity: 0.7 }}>{icon}</span>}
        {title}
      </h3>
      {action && (
        <a href="#" style={{
          fontSize: 12, color: COSMICA_SAAS.accentCyan, fontWeight: 600,
          textDecoration: 'none',
        }}>{action} →</a>
      )}
    </div>
  );
}

// ─── Breadcrumb ────────────────────────────────────────────────────────
function Breadcrumb({ items }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6,
                  fontSize: 12, color: COSMICA_SAAS.textMuted, marginBottom: 14 }}>
      {items.map((it, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span style={{ opacity: 0.5 }}>›</span>}
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 4,
            color: i === items.length - 1 ? COSMICA_SAAS.textPrimary : COSMICA_SAAS.textMuted,
            fontWeight: i === items.length - 1 ? 500 : 400,
          }}>
            {it.icon && <span>{it.icon}</span>}
            {it.label}
          </span>
        </React.Fragment>
      ))}
    </div>
  );
}

// ─── Order number (Rajdhani mono) ─────────────────────────────────────
function OrderNum({ children }) {
  return (
    <span style={{
      fontFamily: COSMICA_SAAS.fontDisplay,
      fontWeight: 700, fontSize: 14,
      color: COSMICA_SAAS.accentCyan,
      letterSpacing: '0.02em',
    }}>{children}</span>
  );
}

// ─── Avatar ────────────────────────────────────────────────────────────
function Avatar2({ name = '?', size = 32, accent }) {
  const initials = name.split(/\s+/).map((s) => s[0]).slice(0, 2).join('').toUpperCase();
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: `linear-gradient(135deg, ${accent || COSMICA_SAAS.accentCyan}, ${COSMICA_SAAS.accentOrange})`,
      color: '#050B14',
      fontFamily: COSMICA_SAAS.fontDisplay, fontWeight: 700, fontSize: size * 0.42,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      flexShrink: 0, letterSpacing: '-0.01em',
    }}>{initials}</div>
  );
}

// ─── Background (cosmic glow points) ───────────────────────────────────
function SpaceBg() {
  return (
    <div style={{ position: 'absolute', inset: 0, overflow: 'hidden',
                  pointerEvents: 'none' }}>
      <div style={{
        position: 'absolute', top: '8%', left: '-5%',
        width: 380, height: 380, borderRadius: '50%',
        background: `radial-gradient(circle, ${COSMICA_SAAS.accentCyan}22, transparent 70%)`,
        filter: 'blur(20px)',
      }} />
      <div style={{
        position: 'absolute', top: '50%', right: '-8%',
        width: 460, height: 460, borderRadius: '50%',
        background: `radial-gradient(circle, ${COSMICA_SAAS.accentOrange}1A, transparent 70%)`,
        filter: 'blur(20px)',
      }} />
      <div style={{
        position: 'absolute', bottom: '-10%', left: '30%',
        width: 360, height: 360, borderRadius: '50%',
        background: `radial-gradient(circle, ${COSMICA_SAAS.danger}1A, transparent 70%)`,
        filter: 'blur(20px)',
      }} />
    </div>
  );
}

window.COSMICA_SAAS = COSMICA_SAAS;
window.SaaSGlassCard = GlassCard;
window.SaaSBadge = Badge;
window.SaaSButton = Button;
window.SaaSKPI = KPI;
window.SaaSInput = Input;
window.SaaSPillGroup = PillGroup;
window.SaaSSectionDivider = SectionDivider;
window.SaaSBreadcrumb = Breadcrumb;
window.SaaSOrderNum = OrderNum;
window.SaaSAvatar = Avatar2;
window.SaaSSpaceBg = SpaceBg;
