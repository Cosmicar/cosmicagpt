// Cosmica SaaS — Consola del Técnico (desktop remote-session view).
// Big screen mirror on the left, control panels on the right.

function FakeWindow({ title, accent, rows = 4, style }) {
  return (
    <div style={{
      background: 'rgba(255,255,255,0.95)', borderRadius: 6,
      boxShadow: '0 14px 30px rgba(0,0,0,0.4)',
      overflow: 'hidden', ...style,
    }}>
      <div style={{ height: 22, background: '#e3e3e8',
                    display: 'flex', alignItems: 'center', gap: 4, paddingInline: 8 }}>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#ff5f57' }} />
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#ffbd2e' }} />
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#28c840' }} />
        <span style={{ flex: 1, textAlign: 'center', fontSize: 10,
                       color: '#666', fontFamily: 'sans-serif' }}>{title}</span>
      </div>
      <div style={{ padding: 12, fontFamily: 'monospace', fontSize: 9, color: '#222' }}>
        <div style={{ height: 8, width: '60%', background: accent || '#444', marginBottom: 7,
                      borderRadius: 2 }} />
        {Array.from({ length: rows }).map((_, i) => (
          <div key={i} style={{
            height: 5, width: `${85 - i * 8}%`, background: '#cfcfcf',
            marginBottom: 4, borderRadius: 1,
          }} />
        ))}
      </div>
    </div>
  );
}

function SaaSConsolaView() {
  return (
    <main style={{ flex: 1, overflow: 'hidden', padding: '20px 24px 24px',
                   display: 'grid', gridTemplateColumns: '1.45fr 1fr', gap: 18,
                   gridTemplateRows: 'auto 1fr', alignItems: 'stretch' }}>
      {/* Header strip spans full width */}
      <div style={{ gridColumn: '1 / -1', display: 'flex',
                    alignItems: 'center', justifyContent: 'space-between',
                    gap: 16, padding: '12px 20px',
                    background: 'linear-gradient(135deg, rgba(0,229,255,0.08), transparent 60%), rgba(255,255,255,0.03)',
                    border: `1px solid ${COSMICA_SAAS.accentCyan}55`,
                    borderRadius: 12,
                    boxShadow: `0 0 24px ${COSMICA_SAAS.cyanGlow}` }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <span style={{
            display: 'inline-flex', alignItems: 'center', gap: 6,
            padding: '5px 11px', background: 'rgba(16,185,129,0.18)',
            border: `1px solid ${COSMICA_SAAS.success}`, borderRadius: 999,
            fontSize: 11.5, color: COSMICA_SAAS.success, fontWeight: 700,
            letterSpacing: '0.05em', textTransform: 'uppercase',
          }}>
            <span style={{
              width: 7, height: 7, borderRadius: '50%', background: COSMICA_SAAS.success,
              boxShadow: `0 0 8px ${COSMICA_SAAS.success}`,
              animation: 'cosmica-pulse 1.6s ease-out infinite',
            }} />
            sesión en vivo
          </span>
          <SaaSAvatar name="Camila Pérez" size={36} />
          <div>
            <div style={{ fontSize: 14.5, fontWeight: 600, color: COSMICA_SAAS.textPrimary,
                          display: 'flex', alignItems: 'center', gap: 8 }}>
              Camila Pérez
              <SaaSOrderNum>#REM-2942</SaaSOrderNum>
            </div>
            <div style={{ fontSize: 11, color: COSMICA_SAAS.textMuted, marginTop: 2 }}>
              Mendoza · Plan Oro · 1ª vez · conectada desde CAMILA-PC
            </div>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 10, color: COSMICA_SAAS.textMuted,
                          letterSpacing: '0.1em', textTransform: 'uppercase',
                          fontWeight: 700 }}>Código sesión</div>
            <div style={{ fontFamily: COSMICA_SAAS.fontMono, fontSize: 18,
                          color: COSMICA_SAAS.accentCyan, letterSpacing: '0.16em',
                          fontWeight: 600, marginTop: 2 }}>X-7K-29F</div>
          </div>
          <div style={{ width: 1, height: 36, background: COSMICA_SAAS.border }} />
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 10, color: COSMICA_SAAS.textMuted,
                          letterSpacing: '0.1em', textTransform: 'uppercase',
                          fontWeight: 700 }}>Tiempo</div>
            <div style={{ fontFamily: COSMICA_SAAS.fontMono, fontSize: 18,
                          color: COSMICA_SAAS.textPrimary, marginTop: 2,
                          fontWeight: 600 }}>00:14:32</div>
          </div>
          <SaaSButton variant="secondary" size="sm" icon="📞">Llamar</SaaSButton>
          <button style={{
            padding: '7px 16px', borderRadius: 8,
            background: 'rgba(255,0,127,0.12)',
            border: `1px solid ${COSMICA_SAAS.danger}66`,
            color: COSMICA_SAAS.danger, fontSize: 13, fontWeight: 700,
            fontFamily: COSMICA_SAAS.font, cursor: 'pointer',
          }}>⏻ Cortar conexión</button>
        </div>
      </div>

      {/* LEFT — screen mirror */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 14,
                    minHeight: 0 }}>
        <div style={{
          flex: 1, borderRadius: 14, position: 'relative', overflow: 'hidden',
          background: 'linear-gradient(135deg, #0e1a2f, #1a2747 60%, #0a1428)',
          border: `1px solid ${COSMICA_SAAS.border}`,
          boxShadow: '0 20px 40px rgba(0,0,0,0.5)',
        }}>
          {/* fake Windows wallpaper texture */}
          <div style={{
            position: 'absolute', inset: 0,
            background: `radial-gradient(circle at 30% 20%, ${COSMICA_SAAS.accentCyan}22, transparent 50%),
                         radial-gradient(circle at 70% 80%, ${COSMICA_SAAS.accentOrange}1A, transparent 50%)`,
            pointerEvents: 'none',
          }} />

          {/* recording overlay */}
          <div style={{
            position: 'absolute', top: 16, left: 18,
            display: 'flex', alignItems: 'center', gap: 8,
            background: 'rgba(0,0,0,0.55)', padding: '6px 14px',
            borderRadius: 999, backdropFilter: 'blur(8px)',
            border: `1px solid rgba(255,255,255,0.12)`,
          }}>
            <span style={{
              width: 8, height: 8, borderRadius: '50%',
              background: COSMICA_SAAS.danger,
              boxShadow: `0 0 8px ${COSMICA_SAAS.danger}`,
              animation: 'cosmica-blink 1.2s ease infinite',
            }} />
            <span style={{ fontSize: 11, color: '#fff',
                           fontFamily: COSMICA_SAAS.fontMono,
                           letterSpacing: '0.1em', fontWeight: 600 }}>
              REC · 00:14:32
            </span>
          </div>

          {/* resolution / connection meta */}
          <div style={{
            position: 'absolute', top: 16, right: 18,
            display: 'flex', alignItems: 'center', gap: 10,
            background: 'rgba(0,0,0,0.55)', padding: '6px 14px',
            borderRadius: 999, backdropFilter: 'blur(8px)',
            border: `1px solid rgba(255,255,255,0.12)`,
            fontSize: 11, fontFamily: COSMICA_SAAS.fontMono, color: '#fff',
          }}>
            <span>1920×1080</span>
            <span style={{ opacity: 0.5 }}>·</span>
            <span style={{ color: COSMICA_SAAS.success }}>● 62 ms</span>
          </div>

          {/* desktop windows */}
          <FakeWindow title="Mozilla Firefox" accent="#FF7139" rows={5}
            style={{ position: 'absolute', left: '8%', top: '14%', width: '46%' }} />
          <FakeWindow title="Administrador de tareas" accent={COSMICA_SAAS.accentOrange} rows={4}
            style={{ position: 'absolute', left: '46%', top: '32%', width: '40%' }} />
          <FakeWindow title="Símbolo del sistema — chkdsk" accent={COSMICA_SAAS.accentCyan} rows={6}
            style={{ position: 'absolute', left: '20%', top: '54%', width: '52%' }} />

          {/* taskbar */}
          <div style={{
            position: 'absolute', left: 0, right: 0, bottom: 0,
            height: 32, background: 'rgba(0,0,0,0.6)',
            backdropFilter: 'blur(8px)',
            borderTop: '1px solid rgba(255,255,255,0.06)',
            display: 'flex', alignItems: 'center', gap: 6, paddingInline: 12,
          }}>
            <span style={{
              width: 18, height: 18, borderRadius: 4,
              background: `linear-gradient(135deg, ${COSMICA_SAAS.accentCyan}, ${COSMICA_SAAS.accentOrange})`,
            }} />
            <span style={{ width: 14, height: 14, borderRadius: 3, background: 'rgba(255,255,255,0.2)' }} />
            <span style={{ width: 14, height: 14, borderRadius: 3, background: 'rgba(255,255,255,0.2)' }} />
            <span style={{ width: 14, height: 14, borderRadius: 3, background: 'rgba(255,255,255,0.2)' }} />
            <span style={{ flex: 1 }} />
            <span style={{ fontSize: 11, color: '#fff', fontFamily: COSMICA_SAAS.fontMono }}>
              14:32 · 14 may
            </span>
          </div>

          {/* technician cursor */}
          <div style={{
            position: 'absolute', left: '55%', top: '52%',
            display: 'flex', alignItems: 'flex-start', gap: 4,
            pointerEvents: 'none',
          }}>
            <svg width="22" height="22" viewBox="0 0 22 22">
              <path d="M2 2 L2 18 L7 14 L10 21 L14 19 L11 12 L17 12 Z"
                    fill={COSMICA_SAAS.accentCyan}
                    stroke="#050B14" strokeWidth="1.5" />
            </svg>
            <span style={{
              padding: '3px 8px', borderRadius: 6,
              background: COSMICA_SAAS.accentCyan, color: '#050B14',
              fontSize: 10, fontWeight: 700, fontFamily: COSMICA_SAAS.font,
              boxShadow: `0 0 10px ${COSMICA_SAAS.cyanGlow}`,
              transform: 'translateY(14px)',
            }}>LUCAS</span>
          </div>
        </div>

        {/* Toolbar — pointer / annotate / focus / lock */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(6, 1fr)', gap: 8 }}>
          {[
            { l: 'Cursor',     i: '🖱',  on: true  },
            { l: 'Anotar',     i: '✎',   on: false },
            { l: 'Foco',       i: '◎',   on: false },
            { l: 'Bloquear',   i: '🔒',  on: false },
            { l: 'Captura',    i: '📸',  on: false },
            { l: 'Transferir', i: '📁',  on: false },
          ].map((b) => (
            <button key={b.l} style={{
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              gap: 7, padding: '10px 12px', borderRadius: 10, cursor: 'pointer',
              background: b.on ? 'rgba(0,229,255,0.15)' : 'rgba(255,255,255,0.04)',
              border: `1px solid ${b.on ? COSMICA_SAAS.accentCyan : COSMICA_SAAS.border}`,
              color: b.on ? COSMICA_SAAS.accentCyan : COSMICA_SAAS.textPrimary,
              fontSize: 12.5, fontWeight: 600, fontFamily: COSMICA_SAAS.font,
            }}>
              <span style={{ fontSize: 14 }}>{b.i}</span>{b.l}
            </button>
          ))}
        </div>
      </div>

      {/* RIGHT — control panels */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12,
                    overflow: 'auto', minHeight: 0, paddingRight: 4 }}>

        {/* Quoted problem */}
        <SaaSGlassCard padding={14}>
          <div style={{ display: 'flex', gap: 12 }}>
            <div style={{ width: 3, background: COSMICA_SAAS.accentCyan,
                          borderRadius: 999, flexShrink: 0 }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.08em',
                            color: COSMICA_SAAS.textMuted, textTransform: 'uppercase',
                            marginBottom: 6 }}>
                Problema reportado
              </div>
              <div style={{ fontSize: 12.5, color: COSMICA_SAAS.textPrimary, lineHeight: 1.5 }}>
                "Mi notebook se trabó esta mañana y desde ayer cuando abro Chrome aparece publicidad de la nada."
              </div>
              <div style={{ marginTop: 8, display: 'flex', gap: 5, flexWrap: 'wrap' }}>
                <SaaSBadge tone="cyan">Lentitud</SaaSBadge>
                <SaaSBadge tone="pink">Virus</SaaSBadge>
                <SaaSBadge tone="orange">Urgente</SaaSBadge>
              </div>
            </div>
          </div>
        </SaaSGlassCard>

        {/* Specs */}
        <SaaSGlassCard padding={14}>
          <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.08em',
                        color: COSMICA_SAAS.textMuted, textTransform: 'uppercase',
                        marginBottom: 10 }}>
            Equipo conectado
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
            {[
              { l: 'SO',         v: 'Windows 11 Pro 23H2' },
              { l: 'CPU',        v: 'i5-1135G7 · 87%',  warn: true },
              { l: 'RAM',        v: '8 GB · 7.2 GB usado', warn: true },
              { l: 'Disco',      v: 'SSD 256 GB · 78%', warn: false },
              { l: 'Antivirus',  v: 'Ninguno',          warn: true },
              { l: 'Red',        v: '54 Mbps · estable' },
            ].map((s) => (
              <div key={s.l} style={{
                padding: '8px 10px', borderRadius: 8,
                background: 'rgba(255,255,255,0.03)',
                border: `1px solid ${COSMICA_SAAS.border}`,
              }}>
                <div style={{ fontSize: 9.5, color: COSMICA_SAAS.textMuted,
                              fontWeight: 700, letterSpacing: '0.08em',
                              textTransform: 'uppercase' }}>{s.l}</div>
                <div style={{ fontFamily: COSMICA_SAAS.fontMono, fontSize: 11.5,
                              color: s.warn ? COSMICA_SAAS.accentOrange : COSMICA_SAAS.textPrimary,
                              marginTop: 2 }}>
                  {s.warn && '⚠ '}{s.v}
                </div>
              </div>
            ))}
          </div>
        </SaaSGlassCard>

        {/* Toolbox */}
        <SaaSGlassCard padding={14}>
          <div style={{ display: 'flex', justifyContent: 'space-between',
                        alignItems: 'center', marginBottom: 10 }}>
            <span style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.08em',
                           color: COSMICA_SAAS.textMuted, textTransform: 'uppercase' }}>
              Herramientas
            </span>
            <span style={{ fontSize: 10.5, color: COSMICA_SAAS.success,
                           fontFamily: COSMICA_SAAS.fontMono }}>
              ● 1 corriendo
            </span>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
            {[
              { l: 'Escaneo',  i: '🦠', tone: 'pink',   on: true,  prog: 0.6 },
              { l: 'Limpieza', i: '🧹', tone: 'cyan',   on: false },
              { l: 'Office',   i: '📄', tone: 'cyan',   on: false },
              { l: 'Drivers',  i: '⚙',  tone: 'orange', on: false },
              { l: 'Backup',   i: '☁',  tone: 'cyan',   on: false },
              { l: 'Notas',    i: '✎',  tone: 'gray',   on: false },
            ].map((tool) => (
              <button key={tool.l} style={{
                position: 'relative', overflow: 'hidden',
                padding: '12px 8px', borderRadius: 10, cursor: 'pointer',
                background: tool.on ? 'rgba(255,0,127,0.10)' : 'rgba(255,255,255,0.04)',
                border: `1px solid ${tool.on ? COSMICA_SAAS.danger : COSMICA_SAAS.border}`,
                color: COSMICA_SAAS.textPrimary,
                display: 'flex', flexDirection: 'column', gap: 4, alignItems: 'center',
                fontSize: 11.5, fontWeight: 600, fontFamily: COSMICA_SAAS.font,
              }}>
                <span style={{ fontSize: 18 }}>{tool.i}</span>
                {tool.l}
                {tool.on && (
                  <div style={{
                    position: 'absolute', left: 0, bottom: 0, height: 3,
                    width: `${tool.prog * 100}%`,
                    background: COSMICA_SAAS.danger,
                    boxShadow: `0 0 8px ${COSMICA_SAAS.danger}`,
                  }} />
                )}
              </button>
            ))}
          </div>
        </SaaSGlassCard>

        {/* AI / Suggestion */}
        <SaaSGlassCard padding={14} style={{
          background: `linear-gradient(135deg, ${COSMICA_SAAS.accentCyan}18, transparent 70%)`,
          borderColor: `${COSMICA_SAAS.accentCyan}66`,
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
            <span style={{ fontSize: 14 }}>◇</span>
            <span style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.08em',
                           color: COSMICA_SAAS.accentCyan, textTransform: 'uppercase' }}>
              Sugerencia Cósmica AI
            </span>
          </div>
          <div style={{ fontSize: 12.5, color: COSMICA_SAAS.textPrimary,
                        fontWeight: 500, marginBottom: 4 }}>
            Limpiar extensiones de Chrome (7 sospechosas)
          </div>
          <div style={{ fontSize: 11.5, color: COSMICA_SAAS.textMuted, lineHeight: 1.45 }}>
            Detecté actividad anómala en 7 extensiones. Recomiendo eliminarlas antes de continuar con la optimización.
          </div>
          <div style={{ display: 'flex', gap: 6, marginTop: 10 }}>
            <SaaSButton variant="primary" size="sm" style={{ flex: 1 }}>Ejecutar</SaaSButton>
            <SaaSButton variant="ghost" size="sm">Saltar</SaaSButton>
          </div>
        </SaaSGlassCard>

        {/* Log */}
        <SaaSGlassCard padding={14}>
          <div style={{ display: 'flex', justifyContent: 'space-between',
                        alignItems: 'center', marginBottom: 8 }}>
            <span style={{ fontFamily: COSMICA_SAAS.fontMono, fontSize: 10.5,
                           color: COSMICA_SAAS.textMuted, letterSpacing: '0.06em' }}>
              cosmica@remote ~ %
            </span>
            <span style={{ fontFamily: COSMICA_SAAS.fontMono, fontSize: 10,
                           color: COSMICA_SAAS.success }}>● live</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 3 }}>
            {[
              { t: '14:32:14', tone: 'ok',   text: 'kaspersky --scan complete · 14 threats removed' },
              { t: '14:31:02', tone: 'info', text: 'cleaning %TEMP% · 4.2 GB recovered' },
              { t: '14:29:48', tone: 'warn', text: 'chrome.exe extensions: 7 suspicious' },
              { t: '14:27:11', tone: 'ok',   text: 'cosmica.agent connected to CAMILA-PC' },
              { t: '14:24:02', tone: 'info', text: 'session_id=X-7K-29F established' },
            ].map((l, i) => {
              const c = { ok: COSMICA_SAAS.success, warn: COSMICA_SAAS.accentOrange,
                          info: COSMICA_SAAS.accentCyan, neutral: COSMICA_SAAS.textMuted }[l.tone];
              const sigil = { ok: '✓', warn: '!', info: '›', neutral: '·' }[l.tone];
              return (
                <div key={i} style={{ display: 'flex', gap: 8,
                                      fontFamily: COSMICA_SAAS.fontMono,
                                      fontSize: 10.5, lineHeight: 1.5 }}>
                  <span style={{ color: COSMICA_SAAS.textMuted, opacity: 0.7 }}>{l.t}</span>
                  <span style={{ color: c, width: 10 }}>{sigil}</span>
                  <span style={{ color: COSMICA_SAAS.textPrimary, opacity: 0.85 }}>{l.text}</span>
                </div>
              );
            })}
          </div>
        </SaaSGlassCard>

        {/* Chat */}
        <SaaSGlassCard padding={12}>
          <div style={{ fontSize: 10.5, fontWeight: 700, letterSpacing: '0.08em',
                        color: COSMICA_SAAS.textMuted, textTransform: 'uppercase',
                        marginBottom: 8 }}>
            Chat con Camila
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 5 }}>
            {[
              { from: 'them', text: '¿Puedo seguir usando WhatsApp Web mientras tanto?' },
              { from: 'me',   text: 'Mejor no, recién termino con esto y avanzamos juntos.' },
              { from: 'them', text: 'Dale, gracias 🙏' },
            ].map((m, i) => (
              <div key={i} style={{ display: 'flex',
                                    justifyContent: m.from === 'me' ? 'flex-end' : 'flex-start' }}>
                <div style={{
                  maxWidth: '85%', padding: '6px 10px', borderRadius: 12,
                  background: m.from === 'me' ? COSMICA_SAAS.accentCyan
                                              : 'rgba(255,255,255,0.07)',
                  color: m.from === 'me' ? '#050B14' : COSMICA_SAAS.textPrimary,
                  fontSize: 12, lineHeight: 1.35,
                  borderBottomRightRadius: m.from === 'me' ? 3 : 12,
                  borderBottomLeftRadius:  m.from === 'me' ? 12 : 3,
                }}>{m.text}</div>
              </div>
            ))}
          </div>
          <div style={{
            marginTop: 8, padding: '6px 10px',
            background: 'rgba(255,255,255,0.04)',
            border: `1px solid ${COSMICA_SAAS.border}`, borderRadius: 8,
            fontSize: 12, color: COSMICA_SAAS.textMuted,
            display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          }}>
            <span>Escribir un mensaje&hellip;</span>
            <span style={{ color: COSMICA_SAAS.accentCyan }}>↩</span>
          </div>
        </SaaSGlassCard>

      </div>
    </main>
  );
}

window.SaaSConsolaView = SaaSConsolaView;
